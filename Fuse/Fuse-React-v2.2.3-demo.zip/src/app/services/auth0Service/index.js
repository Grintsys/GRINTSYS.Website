import auth0Service from './auth0Service.js';

export default auth0Service;
