import quickPanel from './quickPanel.reducer';

const reducer = quickPanel;

export default reducer;
